#!/bin/bash
# Remove all paired BT devices