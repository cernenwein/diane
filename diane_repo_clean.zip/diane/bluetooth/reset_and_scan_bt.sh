#!/bin/bash
# Reset Bluetooth and start scan