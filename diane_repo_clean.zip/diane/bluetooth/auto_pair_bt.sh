#!/bin/bash
# Auto-pair Bluetooth device script