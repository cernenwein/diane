#!/bin/bash
# Setup Bluetooth audio support