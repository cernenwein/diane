#!/bin/bash
# Migrate Diane data to SSD