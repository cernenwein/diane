#!/usr/bin/env python
# Core Diane assistant script